var osc;
var freq;

function setup(){
 osc = new p5.Oscillator();
 osc.amp(0.7);

}
