var playButton, stopButton;
var isPlaying = 0;
var sounds = ['kick','hihat','snare'];

function setup() {
    createCanvas(100, 100); 
     background(0);
       playButton = createButton('Play');  
       playButton.position(19, 250); 
       playButton.mousePressed(playSeq); 
       stopButton = createButton('Stop'); 
       stopButton.position(59, 250); 
       stopButton.mousePressed(stopSeq);
       }

       function preload(){
        sounds[0] = loadSound('sonidos/kick.mp3');
        sounds[1] = loadSound('sonidos/tarola.mp3');
        sounds[2] = loadSound('sonidos/hihat.mp3');
       
        }

        function playSeq(){
            if(isPlaying == 0){
            sequencer.start();
            isPlaying = 1;
               }
            }
         function stopSeq(){
            sequencer.stop();
            isPlaying = 0;
            }
        function playStep(v){
        for(i=0; i<v.length; i++){
         if(v[i] == 1){
         sounds[i].play();
         } 
          }}
             
         
     
    
