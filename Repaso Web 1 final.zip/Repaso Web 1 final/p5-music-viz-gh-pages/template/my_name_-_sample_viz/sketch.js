/*
  Empty example
 */

function preload() {
  // add the path to your sound
  // sound = loadSound('../../music/');
}

function setup() {

}

function draw() {

}