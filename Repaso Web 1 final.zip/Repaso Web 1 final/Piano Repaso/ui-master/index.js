'use strict';

import NexusUI from './lib/main';

export default NexusUI;
